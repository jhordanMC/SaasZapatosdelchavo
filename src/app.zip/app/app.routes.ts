import { Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login';
import { OlvidecontraComponent } from './pages/olvidecontra/olvidecontra';
import { DashboardUsuarioComponent } from './pages/usuario/dashboard/dashboard';
import { DashboardAdminComponent } from './pages/admin/dashboard/dashboard';
import { EmpresasComponent } from './pages/admin/empresas/empresas';
import { EmpresaDetalleComponent } from './pages/admin/empresa-detalle/empresa-detalle';
import { UsuariosComponent } from './pages/admin/usuarios/usuarios';

export const routes: Routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
   { path: 'olvide-contrasena', component: OlvidecontraComponent },

   //vista admin
   { path: 'admin/dashboard', component: DashboardAdminComponent },
   { path: 'admin/empresas', component: EmpresasComponent },
   { path: 'admin/empresas/:id', component: EmpresaDetalleComponent },
   { path: 'admin/usuarios', component: UsuariosComponent },

   //vista usuario
   { path: 'dashboardu', component: DashboardUsuarioComponent },
];